export class TeamModel {
  public id: number;
  public name: string;
}
